<?php

include 'essencial.php';
include 'headers.php';
include 'bootstrap.php';

?>

</head>

</body>
<?php include 'navbar.php'; ?>

<?php include 'doc/about.php'; ?>


<?php include 'footer.php'; ?>



