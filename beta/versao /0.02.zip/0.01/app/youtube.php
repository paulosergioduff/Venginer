<?php
$idvideo = $_GET['v'];
?>

<iframe width="560" height="280" src="https://www.youtube.com/embed/<?php echo $idvideo; ?>?autoplay=1" frameborder="0" allowfullscreen></iframe>
