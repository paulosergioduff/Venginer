<?php 

header("Content-type: text/html;charset=utf-8");

?>


var item=new Array();

// "Endereço","Título","Palavras-chave","Descrição"

item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");
item[item.length]=new Array("http://www.brdesign.net","","Título<br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg>","Descrição: criação de sites desenvolvimento asp javascript flash scripts web homepages internet intranet","Especializado em criações de websites e soluções criativas pra internet e intranet.");
item[item.length]=new Array("http://www.mundoplaystation.kit.net","","Mundo Playstation","games vídeo-games jogos playstation","Site de games voltado ao console playstation.");
item[item.length]=new Array("http://www.buscaon-line.rg3.net","","Busca On-line","busca sites buscador internet","Site de busca dividido em categorias.");

item[item.length]=new Array("http://www.e-dominios.com.br/?from=5301","","E-Domínios","registro domínios sites","Querendo registrar seu domínio. Visite-nos, apenas 39,90 anuais");

item[item.length]=new Array("http://www.e-dominios.com.br/?from=5301","","Novo","registro domínios sites","Querendo registrar seu domínio. Visite-nos, apenas 39,90 anuais");

item[item.length]=new Array("http://www.e-dominios.com.br/?from=5301","","<?php echo "olá novo 2"; ?>","registro domínios sites","Querendo registrar seu domínio. Visite-nos, apenas 39,90 anuais Método");
