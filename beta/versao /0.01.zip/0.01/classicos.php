var item=new Array();

// "Endereço","Título","Palavras-chave","Descrição"


item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");

item[item.length]=new Array("watch?v=jNQXAC9IVRw",""," Me at the zoo<br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg><br>"," The first video on YouTube..","");

item[item.length]=new Array("uO5gfQRdzs0",""," De Homem a Penha não tem Pena<br><img src=http://img.youtube.com/vi/uO5gfQRdzs0/default.jpg>"," 286 referências investigando a relação de gênero em violência doméstica: http://csulb.edu/~mfiebert/assault.htm Matéria sobre a pesquisa no Brasil que conclu....","");

item[item.length]=new Array("WodF95r8Ay8&n=0",""," 15/03: Eu Não Vou<br><img src=http://img.youtube.com/vi/WodF95r8Ay8/default.jpg>"," Amanhã é dia de protesto, e desse eu não pretendo participar. ----------- Música: Wallpaper/Modern Jazz Samba por Kevin MacLeod (incompetech.com). Licensed u....","");

item[item.length]=new Array("watch?v=u8id9g-Ct6s&n=0",""," Os Cavaleiros do Zodiaco Filme 2 : A Grande Batalha dos Deuses<br><img src=http://img.youtube.com/vi/u8id9g-Ct6s/default.jpg>"," Sinopse: Odin é o deus supremo dos deuses da mitologia nórdica. Senhor da mágia e da sabedoria, Odin é detentor da lendária espada Balmung. Possui como monta....","");

item[item.length]=new Array("watch?v=CpseG8Tif2c&n=0","","<a href=watch?v=CpseG8Tif2c> 6 PREVISÕES QUE OS SIMPSONS FIZERAM (E ACERTARAM)</a><br><img src=http://img.youtube.com/vi/CpseG8Tif2c/default.jpg>"," Inscreva-se no canal: http://goo.gl/En1Gmd Assista outras listas: http://goo.gl/IG7nqk Fanpage: http://goo.gl/ubF733 Uma vez acabei me perdendo em uma feira ....","");

item[item.length]=new Array("watch?v=k5hmwk-Vv30&n=0","","<a href=watch?v=k5hmwk-Vv30> JASPION EP 21 PARTE 3</a><br><img src=http://img.youtube.com/vi/k5hmwk-Vv30/default.jpg>","Descrição Teste","");

item[item.length]=new Array("watch?v=k5hmwk-Vv30&n=0","","<a href=watch?v=k5hmwk-Vv30> JASPION EP 21 PARTE 3</a><br><img src=http://img.youtube.com/vi/k5hmwk-Vv30/default.jpg>","Descrição Teste 2 testando","");

item[item.length]=new Array("watch?v=34toH08IRwU&n=0","","<a href=watch?v=34toH08IRwU> GTA V - Entrando em QUATRO BURACOS, Corrida NOVA</a><br><img src=http://img.youtube.com/vi/34toH08IRwU/default.jpg>"," Loja Parceira - Playstation 4, XBOX ONE, games e acessórios: http://bit.ly/1qZjQvD (cupom com 5% de desconto, aproveitem!) INSCREVA-SE NO CANAL - http://goo.....","");
