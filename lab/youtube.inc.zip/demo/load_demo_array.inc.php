<?php
/*
 http://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0
 @author     Richard Wagener <code@securebucket.com>
*/
$i = 0;
$i++; // id = 1;
$vidarray[$i]['ytid'] = 'DMrGCTZAr2M';
$vidarray[$i]['title'] = 'DUB FX and Flower Fairy "live" a...';
$vidarray[$i]['details'] = '';
$vidarray[$i]['thumbnail'] = '';

$i++; // id = 2;
$vidarray[$i]['ytid'] = 'KaqC5FnvAEc';
$vidarray[$i]['title'] = 'Trolling Saruman';
$vidarray[$i]['details'] = '';
$vidarray[$i]['thumbnail'] = '';

$i++; // id = 3;
$vidarray[$i]['ytid'] = 'DUgBOUpUbg4';
$vidarray[$i]['title'] = 'Is this thing on?';
$vidarray[$i]['details'] = '';
$vidarray[$i]['thumbnail'] = '';

$i++;  // id = 4;
$vidarray[$i]['ytid'] = 'G1aWk9Y9cMA';
$vidarray[$i]['title'] = 'MILLION DOLLAR HOLE IN ONE';
$vidarray[$i]['details'] = '';
$vidarray[$i]['thumbnail'] = '';
?>