﻿function AbrirAjax() {
	var xmlhttp;
	try {
		//Para o Internet Explorer	
 		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} 
		catch(e) {
 			try {
  				//IE8	
  				xmlhttp = getXMLHTTP();
 			} 
 			catch(ex) {
  				try {
   					//Para todos os outros Browsers (FireFox,Opera, etc ...)
   					xmlhttp = new XMLHttpRequest();
  				} 
  				catch(exc) {
   					alert("Seu navegador não tem recursos para uso de Ajax");
   					xmlhttp = null;
  				}
 		}
	}
	return xmlhttp;
}

