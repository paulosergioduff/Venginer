<?php 

	include('config.php');

	if(isset($_REQUEST['nome'])) {
	
		// recebendo o valor passado
		$recNome = $_REQUEST['nome'];

		// verificando se o nome já existe
		$select = mysql_query("select cliques, nome from contar where nome = '$recNome'");
		
		// verificando a quantidade de linhas retornada. se for igual a 1, 
		// o link clicado já existe
		$qtd_linhas = mysql_num_rows($select);
		
		$data = date("Y-m-d");

		if ($qtd_linhas == 1){
		
			$valores = mysql_fetch_row($select);
			
			// acrescentando 1 ao valor dos cliques
			$cont = ($valores[0] + 1);
			
			$atualizando = "update contar set cliques = '$cont', data = '$data' where nome = '$valores[1]'";
			$executando = mysql_query($atualizando) or die(mysql_error());

			echo "Dado alterado corretamente!";
			echo "<br /><br />";
			
		} else{
			// inserindo - campo "clique" recebe valor=1
			$cont = 1;	
			$inserindo = "INSERT INTO contar (cliques, nome, data) VALUES('$cont','$recNome','$data')";
			$executando = mysql_query($inserindo) or die(mysql_error());
		
			echo "Dado inserido corretamente!";
		}
		
		// select trazendo todos os dados cadastrados
		$select_total = mysql_query("select cliques, nome from contar");
		
		// montando a tabela para o exibição na tela
		echo "<table border='0'>";
		echo "<tr align='center'><td>Cliques</td><td>Site</td></tr>";
		while($row = mysql_fetch_array($select_total)){
			echo "<tr><td>".$row['cliques']."</td><td>".$row['nome']."</td></tr>";
		}
		echo "</table>";
	} else { 
		echo 'Erro não identificado!';
	}
?>