<?
header('Content-Type: text/html; charset=utf-8');

// informe os dados corretos para acesso a base de dados
define ("database", "clique");
define ("user", "root");
define ("pass", "");
define ("servidor", "localhost");

$conexao = mysql_connect(servidor, user, pass) or die("Não foi possível conectar no banco");
$base = mysql_select_db(database);
?>