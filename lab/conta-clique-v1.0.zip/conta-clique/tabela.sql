--
-- Database
--

CREATE DATABASE `clique`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `contar`
--

CREATE TABLE IF NOT EXISTS `contar` (
  `cliques` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `data` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;