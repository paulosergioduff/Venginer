<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<!--
	Sistema desenvolvido por Tiago para o site linhadecomando.com
	Este sistema é de uso livre, podendo ser alterado e distribuído livremente.
	Lembre-se de dar os créditos para o site linhadecomando.com
    
    dúvidas - sugestões - melhorias: tiago.agostinho@gmail.com
-->

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Conta Cliques - linhadecomando.com</title>
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript">
$(document).ready(function(){
	$('a').click(function(){		
		var rec = $(this).attr("name");
		$.ajax({
			type: "POST",
			url: "contagem.php",
			data: "nome="+rec,
			success: function(msg){
     			$('#resultado').html(msg);
		   }
		});
	});
});	

</script>
</head>

<body>
	<p class="titulo">Sistema de Contagem de Cliques</p>
	
    <div id="links">
    	<span style="color:#FF0000">Lista de Sites:</span>
        <br /><br />
		<a href="#" id="uol" name="uol">uol</a>&nbsp;&nbsp;
		<a href="#" id="terra" name="terra">terra</a>&nbsp;&nbsp;
		<a href="#" id="ig" name="ig">ig</a>
	</div>
    <hr />
	<p id="resultado"></p>
</body>
</html>
